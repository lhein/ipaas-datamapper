# Installation
> `npm install --save @types/jasmine`

# Summary
This package contains type definitions for Jasmine (http://jasmine.github.io/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/jasmine

Additional Details
 * Last updated: Tue, 17 Jan 2017 21:40:04 GMT
 * Dependencies: none
 * Global values: afterAll, afterEach, beforeAll, beforeEach, describe, expect, fail, fdescribe, fit, it, jasmine, pending, runs, spyOn, waits, waitsFor, xdescribe, xit

# Credits
These definitions were written by Boris Yankov <https://github.com/borisyankov/>, Theodore Brown <https://github.com/theodorejb>, David Pärsson <https://github.com/davidparsson/>.
