"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var http_1 = require('@angular/http');
require('rxjs/add/operator/toPromise');
var Rx_1 = require('rxjs/Rx');
require('rxjs/add/observable/forkJoin');
var field_model_1 = require('../models/field.model');
var document_definition_model_1 = require('../models/document.definition.model');
var mapping_model_1 = require('../models/mapping.model');
var MapperService = (function () {
    function MapperService(http) {
        this.http = http;
        this.mappings = [];
        this.uuidCounter = 0;
        this.baseUUID = "ui.123456";
        this.headers = new http_1.Headers();
        this.headers.append("Content-Type", "application/json");
    }
    MapperService.prototype.getDocumentDefinition = function (isInput, initializedCallback) {
        var _this = this;
        var url = "http://localhost:8585/v2/atlas/java/class?className=com.mediadriver.atlas.java.service.v2.TestAddress";
        url = isInput ? url : "http://localhost:8585/v2/atlas/java/class?className=com.mediadriver.atlas.java.service.v2.TestContact";
        this.http.get(url, { headers: this.headers }).toPromise()
            .then(function (res) { _this.extractDocumentDefinitionData(res, initializedCallback); })
            .catch(this.handleError);
    };
    MapperService.prototype.extractDocumentDefinitionData = function (res, initializedCallback) {
        var body = res.json();
        var fields = [];
        for (var i = 0; i < body.JavaClass.fields.field.length; i++) {
            var f = body.JavaClass.fields.field[i];
            fields.push(new field_model_1.Field(f.name, f.type));
        }
        var d = new document_definition_model_1.DocumentDefinition(body.JavaClass.className, fields);
        initializedCallback(d);
    };
    MapperService.prototype.initializeMappings = function (initializedCallback) {
        var _this = this;
        console.log("Initializing mappings.");
        var url = "http://localhost:8585/v2/atlas/mappings?filter=" + this.baseUUID;
        this.http.get(url, { headers: this.headers }).toPromise()
            .then(function (res) { return _this.extractMappings(res, initializedCallback); })
            .catch(this.handleError);
    };
    MapperService.prototype.extractMappings = function (res, initializedCallback) {
        var _this = this;
        var body = res.json();
        console.log("mappings result.");
        console.log(body);
        console.log(this);
        var entries = body.StringMap.stringMapEntry;
        var mappingNames = [];
        for (var i = 0; i < entries.length; i++) {
            mappingNames.push(entries[i].name);
        }
        var baseURL = "http://localhost:8585/v2/atlas/mapping/";
        var operations = [];
        for (var i = 0; i < mappingNames.length; i++) {
            var url = baseURL + mappingNames[i];
            var operation = this.http.get(url).map(function (res) { return res.json(); });
            operations.push(operation);
        }
        Rx_1.Observable.forkJoin(operations).subscribe(function (data) {
            if (!data) {
                console.log("No pre-existing mappings were found.");
                return;
            }
            console.log(data);
            console.log("Initializing from " + data.length + " fetched mappings.");
            for (var i = 0; i < data.length; i++) {
                var d = data[i];
                for (var fi = 0; fi < d.AtlasMapping.fieldMappings.fieldMapping.length; fi++) {
                    var m = new mapping_model_1.MappingModel();
                    m.saved = true;
                    m.uuid = d.AtlasMapping.name;
                    var fieldMapping = d.AtlasMapping.fieldMappings.fieldMapping[fi];
                    m.inputFields.push(new field_model_1.Field(fieldMapping.inputField.field.name, fieldMapping.inputField.field.type));
                    m.outputFields.push(new field_model_1.Field(fieldMapping.outputField.field.name, fieldMapping.outputField.field.type));
                }
                console.log("in");
                console.log(d);
                console.log("out");
                console.log(m);
                _this.mappings.push(m);
            }
            initializedCallback();
        }, function (err) { return console.error(err); });
    };
    MapperService.prototype.printMappings = function (reason) {
        var msg = "Mapping status for '" + reason + "', current mapping count: " + this.mappings.length;
        for (var i = 0; i < this.mappings.length; i++) {
            msg += "\n\tMapping #" + i + ": " + this.printMapping(this.mappings[i]);
        }
        console.log(msg);
    };
    MapperService.prototype.printMapping = function (m) {
        var inputs = "";
        for (var j = 0; j < m.inputFields.length; j++) {
            inputs += m.inputFields[j].name + ", ";
        }
        var outputs = "";
        for (var j = 0; j < m.outputFields.length; j++) {
            outputs += m.outputFields[j].name + ", ";
        }
        return "uuid: " + m.uuid + ", inputs: {" + inputs + "}, outputs {" + outputs + "}.";
    };
    MapperService.prototype.saveMapping = function (m) {
        console.log("Saving mapping: " + this.printMapping(m));
        this.removeMappingInternal(m);
        this.mappings.push(m);
        this.printMappings("Saved Mapping.");
        this.saveMappingToService(m);
    };
    MapperService.prototype.saveMappingToService = function (m) {
        var payload = this.makeSavePayload();
        var jsonVersion = JSON.stringify(payload);
        //var jsonPretty = JSON.stringify(JSON.parse(jsonVersion),null,2); 
        var url = "http://localhost:8585/v2/atlas/mapping";
        this.http.put(url, jsonVersion, { headers: this.headers }).toPromise()
            .then(function (res) {
            console.log("Got put rest response.");
            console.log(res);
            m.saved = true;
        })
            .catch(this.handleError);
    };
    MapperService.prototype.makeSavePayload = function () {
        /* //example payload
        {
            "AtlasMapping": {
                "jsonType": "com.mediadriver.atlas.v2.AtlasMapping",
                "fieldMappings": {
                        "fieldMapping": [
                            {
                                "inputField": {
                                    "jsonType": "com.mediadriver.atlas.v2.MappedField",
                                    "field": {
                                        "jsonType": "com.mediadriver.atlas.v2.MockField",
                                        "name": "foo",
                                        "value": "bar"
                                    },
                                    "fieldActions": []
                                },
                                "outputField": { } //same as input field..
                            }
                        ]
                    }
                },
                "name": "junit4"
            }
        }
        */ //end example payload
        var jsonMappings = [];
        for (var i = 0; i < this.mappings.length; i++) {
            var m = this.mappings[i];
            var mappingFieldActions = [];
            var mappingFieldActions = [];
            var jsonMapping = {
                "inputField": {
                    "jsonType": "com.mediadriver.atlas.v2.MappedField",
                    "field": this.createPayloadForFields(m.inputFields),
                    "fieldActions": mappingFieldActions
                },
                "outputField": {
                    "jsonType": "com.mediadriver.atlas.v2.MappedField",
                    "field": this.createPayloadForFields(m.outputFields),
                    "fieldActions": mappingFieldActions
                }
            };
            jsonMappings.push(jsonMapping);
        }
        var mappingName = this.baseUUID + "." + Math.floor((Math.random() * 1000000) + 1).toString();
        var payload = {
            "AtlasMapping": {
                "jsonType": "com.mediadriver.atlas.v2.AtlasMapping",
                "name": mappingName,
                "fieldMappings": {
                    "fieldMapping": jsonMappings
                }
            }
        };
        return payload;
    };
    MapperService.prototype.createPayloadForFields = function (fields) {
        var fieldsJson = [];
        for (var j = 0; j < fields.length; j++) {
            var f = fields[j];
            var flatWrapper = {
                "jsonType": "com.mediadriver.atlas.v2.MockField",
                "name": f.name,
                "type": f.type
            };
            //TODO: for now just return the first field
            return flatWrapper;
        }
        return fieldsJson;
    };
    MapperService.prototype.removeMapping = function (m) {
        console.log("Removing mapping: " + this.printMapping(m));
        if (m.saved) {
            var url = "http://localhost:8585/v2/atlas/mapping/" + m.uuid;
            this.http.delete(url, { headers: this.headers }).toPromise()
                .then(function (res) { console.log(res); })
                .catch(this.handleError);
        }
        this.removeMappingInternal(m);
    };
    MapperService.prototype.removeMappingInternal = function (m) {
        for (var i = 0; i < this.mappings.length; i++) {
            if (this.mappings[i].uuid == m.uuid) {
                console.log("Removing mapping: " + this.printMapping(this.mappings[i]));
                this.mappings.splice(i, 1);
                break;
            }
        }
    };
    MapperService.prototype.findMappingForField = function (fieldName, isInput) {
        console.log("Finding mapping for field: " + fieldName + ", input: " + isInput + ", current mapping count: " + this.mappings.length);
        for (var i = 0; i < this.mappings.length; i++) {
            var m = this.mappings[i];
            var fields = isInput ? m.inputFields : m.outputFields;
            for (var j = 0; j < fields.length; j++) {
                if (fields[j].name == fieldName) {
                    return m;
                }
            }
        }
        return null;
    };
    MapperService.prototype.createMapping = function () {
        var m = new mapping_model_1.MappingModel();
        m.uuid = "mapping #" + this.uuidCounter;
        this.uuidCounter++;
        return m;
    };
    MapperService.prototype.handleError = function (error) {
        console.error('An error occurred', error); // for demo purposes only
        return Promise.reject(error.message || error);
    };
    MapperService.prototype.getMappedFields = function (isInput) {
        var result = [];
        for (var i = 0; i < this.mappings.length; i++) {
            var m = this.mappings[i];
            var fields = isInput ? m.inputFields : m.outputFields;
            for (var j = 0; j < fields.length; j++) {
                result.push(fields[j].name);
            }
        }
        return result;
    };
    MapperService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [http_1.Http])
    ], MapperService);
    return MapperService;
}());
exports.MapperService = MapperService;
//# sourceMappingURL=app.services.js.map