"use strict";
var Field = (function () {
    function Field(name, type) {
        this.name = name;
        this.type = type;
    }
    return Field;
}());
exports.Field = Field;
//# sourceMappingURL=field.model.js.map