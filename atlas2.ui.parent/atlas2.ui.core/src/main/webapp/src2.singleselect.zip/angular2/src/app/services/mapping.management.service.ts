import { Injectable } from '@angular/core';
import { Headers, Http, RequestOptions, Response, HttpModule } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/observable/forkJoin';

import { Field } from '../models/field.model';
import { DocumentDefinition } from '../models/document.definition.model';
import { MappingModel } from '../models/mapping.model';

@Injectable()
export class MappingManagementService {	
	private mappings: MappingModel[] = [];
	private uuidCounter: number = 0;
	private baseUUID = "ui.123456";
	private headers: Headers = new Headers();
	
	constructor(private http: Http) { 
		this.headers.append("Content-Type", "application/json");		
	}

	public getDocumentDefinition(isInput: boolean, initializedCallback: Function) {
		var url: string = "http://localhost:8585/v2/atlas/java/class?className=com.mediadriver.atlas.java.service.v2.TestAddress";
		url = isInput ? url : "http://localhost:8585/v2/atlas/java/class?className=com.mediadriver.atlas.java.service.v2.TestContact";		
		this.http.get(url, {headers: this.headers}).toPromise()
			.then((res: Response) => { this.extractDocumentDefinitionData(res, initializedCallback) })
			.catch(this.handleError);
	}	

	private extractDocumentDefinitionData(res: Response, initializedCallback: Function) {	
  		let body = res.json();
  		var fields: Field[] = [];
  		for (let f of body.JavaClass.fields.field) {
  			fields.push(new Field(f.name, f.type));
  		}
  		var d: DocumentDefinition = new DocumentDefinition(body.JavaClass.className, fields);
  		initializedCallback(d);
	}	

	public initializeMappings(initializedCallback: Function) {
		console.log("Initializing mappings.");
		var url = "http://localhost:8585/v2/atlas/mappings?filter=" + this.baseUUID;
		this.http.get(url, {headers: this.headers}).toPromise()
			.then( (res:Response) => this.extractMappings(res, initializedCallback))
			.catch(this.handleError);               
	}

	private extractMappings(res: Response, initializedCallback: Function) {	
  		let body = res.json();

  		console.log("mappings result.");
  		console.log(body);
  		console.log(this);
  		var entries: any[] = body.StringMap.stringMapEntry;
  		var mappingNames: string[] = [];
  		for (let entry of entries) {
  			mappingNames.push(entry.name);
  		}

  		var baseURL: string = "http://localhost:8585/v2/atlas/mapping/";
  		var operations: any[] = [];
  		for (let mappingName of mappingNames) {
	  		var url: string = baseURL + mappingName;
	  		let operation = this.http.get(url).map((res:Response) => res.json());
	  		operations.push(operation);
	  	}       
	  	Observable.forkJoin(operations).subscribe(
	      (data:any) => {
	      	if (!data) {
	      		console.log("No pre-existing mappings were found.");
	      		return;
	      	}
			console.log(data);
	      	console.log("Initializing from " + data.length + " fetched mappings.");
	      	for (let d of data) {
	      		for (let fieldMapping of d.AtlasMapping.fieldMappings.fieldMapping) {
	      			var m: MappingModel = new MappingModel();
	      			m.saved = true;
	      			m.uuid = d.AtlasMapping.name;
	      			m.inputFields.push(new Field(fieldMapping.inputField.field.name, fieldMapping.inputField.field.type));
	      			m.outputFields.push(new Field(fieldMapping.outputField.field.name, fieldMapping.outputField.field.type));

	      		}
	      		console.log("in");
	      		console.log(d);
	      		console.log("out");
	      		console.log(m);
	      		this.mappings.push(m);
	      	}
	      	initializedCallback();
	      },
	      (err:any) => console.error(err)
	    );
	}		

	public printMappings(reason: string) {
		var msg: string = "Mapping status for '" + reason + "', current mapping count: " + this.mappings.length;
		for (var i = 0; i < this.mappings.length; i++) {
			msg += "\n\tMapping #" + i + ": " + this.printMapping(this.mappings[i]);
		}
		console.log(msg);
	}

	public printMapping(m: MappingModel): string {
		var inputs: string = "";
		for (let f of m.inputFields) {
			inputs += f.name + ", ";
		}
		var outputs: string = "";
		for (let f of m.outputFields) {
			outputs += f.name + ", ";
		}
		return "uuid: " + m.uuid + ", inputs: {" + inputs + "}, outputs {" + outputs + "}.";
	}

	public saveMapping(m: MappingModel) {
		console.log("Saving mapping: " + this.printMapping(m));
		this.removeMappingInternal(m);
		this.mappings.push(m);
		this.printMappings("Saved Mapping.");
		this.saveMappingToService(m);
	}

	private saveMappingToService(m: MappingModel) {
		var payload: any[] = this.makeSavePayload();
		var jsonVersion = JSON.stringify(payload);
		//var jsonPretty = JSON.stringify(JSON.parse(jsonVersion),null,2); 
		var url = "http://localhost:8585/v2/atlas/mapping";
		this.http.put(url, jsonVersion, {headers: this.headers}).toPromise()
			.then((res:Response) => {
				console.log("Got put rest response.");
				console.log(res);
				m.saved = true;
			})
			.catch(this.handleError); 
	}

	public makeSavePayload() : any {
		/* //example payload
		{
			"AtlasMapping": {
				"jsonType": "com.mediadriver.atlas.v2.AtlasMapping",
				"fieldMappings": {
						"fieldMapping": [
							{
								"inputField": {
									"jsonType": "com.mediadriver.atlas.v2.MappedField",
									"field": {
										"jsonType": "com.mediadriver.atlas.v2.MockField",
										"name": "foo",
										"value": "bar"
									},
									"fieldActions": []
								},
								"outputField": { } //same as input field..
							}
						]
					}
				},
				"name": "junit4"
			}
		}
		*/ //end example payload
				
		var jsonMappings: any[] = [];
		for (let m of this.mappings) {
			var mappingFieldActions: any[] = [];
			var mappingFieldActions: any[] = [];
			let jsonMapping = { 
				"inputField": {
					"jsonType": "com.mediadriver.atlas.v2.MappedField",
					"field": this.createPayloadForFields(m.inputFields),
					"fieldActions": mappingFieldActions
				},
				"outputField": {
					"jsonType": "com.mediadriver.atlas.v2.MappedField",
					"field": this.createPayloadForFields(m.outputFields),
					"fieldActions": mappingFieldActions
				}
			};					
			jsonMappings.push(jsonMapping);
		}
		
		var mappingName: string = this.baseUUID + "." + Math.floor((Math.random() * 1000000) + 1).toString();
		let payload = {
			"AtlasMapping": {
				"jsonType": "com.mediadriver.atlas.v2.AtlasMapping",
				"name": mappingName,
				"fieldMappings": {
					"fieldMapping": jsonMappings 
				}
			}
		};
		return payload;
	}

	public createPayloadForFields(fields: Field[]) : any {
		var fieldsJson: any[] = [];
		for (let f of fields) {
			let flatWrapper = {
				"jsonType": "com.mediadriver.atlas.v2.MockField",
				"name": f.name, 
				"type": f.type
			};
			//TODO: for now just return the first field
			return flatWrapper;
			//fieldsJson.push({ "field" : flatWrapper });
		}
		return fieldsJson;
	}

	public removeMapping(m: MappingModel) {
		console.log("Removing mapping: " + this.printMapping(m));
		if (m.saved) {
			var url: string = "http://localhost:8585/v2/atlas/mapping/" + m.uuid;
			this.http.delete(url, {headers: this.headers}).toPromise()
				.then((res:Response) => { console.log(res); })
				.catch(this.handleError);  
		}
		this.removeMappingInternal(m);		
	}

	private removeMappingInternal(m: MappingModel) {
		for (var i = 0; i < this.mappings.length; i++) {
			if (this.mappings[i].uuid == m.uuid) {
				console.log("Removing mapping: " + this.printMapping(this.mappings[i]));
				this.mappings.splice(i, 1);
				break;
			}
		}
	}

	public findMappingForField(fieldName: string, isInput:boolean): MappingModel {		
		console.log("Finding mapping for field: " + fieldName + ", input: " + isInput + ", current mapping count: " + this.mappings.length);
		for (let m of this.mappings) {
			var fields: Field[] = isInput ? m.inputFields : m.outputFields;		
			for (let f of fields) {
				if (f.name == fieldName) {
					return m;
				}
			}
		}
		return null;
	}

	public createMapping() {
		var m: MappingModel = new MappingModel();
		m.uuid = "mapping #" + this.uuidCounter;
		this.uuidCounter++;
		return m;
	}

	private handleError(error: any): Promise<any> {
		console.error('An error occurred', error); // for demo purposes only
		return Promise.reject(error.message || error);
	}

	public getMappedFields(isInput: boolean) : string[] {
		var result: string[] = [];
		for (let m of this.mappings) {
			var fields: Field[] = isInput ? m.inputFields : m.outputFields;
			for (let f of fields) {
				result.push(f.name);
			}
		}
		return result;		
	}
}