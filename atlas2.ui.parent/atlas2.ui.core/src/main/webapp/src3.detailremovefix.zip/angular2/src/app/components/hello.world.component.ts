import { Component } from '@angular/core';

@Component({
	selector: 'hello-world',
	template: `<div>hello world!!??</div>`
})
export class HelloWorldComponent { }