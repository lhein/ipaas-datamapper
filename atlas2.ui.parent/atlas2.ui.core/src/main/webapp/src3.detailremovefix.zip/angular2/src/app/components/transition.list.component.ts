import { Component } from '@angular/core';

@Component({
	selector: 'transition-list',
	template: `
	  	<div class='transitionList'></div>
    `
})

export class TransitionListComponent { }